# GameForge Creator — 3D Preview Upgrade

This version preserves the dashboard and concept studio, and adds a browser-playable low-poly 3D exploration prototype.

## Deploy to your existing Netlify site (Android)
1. Extract this ZIP on your phone.
2. Confirm `index.html`, `style.css`, `app.js`, and `README.md` are directly inside the extracted folder.
3. Open the existing Netlify site `tiny-kitten-cfc1ba`, then open Deploys.
4. Use the manual deploy / drag-and-drop area to publish the extracted project folder. Do not delete your site.
5. Wait for Published, then open https://tiny-kitten-cfc1ba.netlify.app/ and refresh.

## Controls
- Desktop: WASD or arrow keys to move.
- Android: use the on-screen directional pad.
- Collect all three glowing crystals; Reset world starts again.

## Notes
- The 3D preview uses Three.js from a public CDN, so it requires an internet connection. If the CDN cannot load, the page will show a clear message.
- This is a small browser prototype, not a compiled Android/iOS game. It does not add user accounts, cloud saving, online multiplayer, or payments.
